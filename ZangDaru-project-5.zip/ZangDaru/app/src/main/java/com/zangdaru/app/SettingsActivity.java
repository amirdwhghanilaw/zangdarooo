package com.zangdaru.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }

    private void build() {
        final Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad * 2);
        sv.addView(col);
        col.addView(Ui.topBar(this, "تنظیمات"), Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        // ---- theme ----
        col.addView(Ui.text(this, "🎨  رنگ برنامه", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 20));
        LinearLayout tr = new LinearLayout(this);
        tr.setOrientation(LinearLayout.HORIZONTAL);
        tr.setBackground(Ui.box(this, p.soft, 20));
        tr.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6), Ui.dp(this, 8));
        for (int i = 0; i < Ui.PALS.length; i++) {
            final int k = i;
            boolean sel = (i == Store.theme(this));
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Ui.DOTS[i]);
            g.setStroke(Ui.dp(this, sel ? 4 : 1), sel ? 0xFF263238 : 0xFFB0BEC5);
            dot.setBackground(g);
            cell.addView(dot, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
            cell.addView(Ui.text(this, Ui.THEME_NAMES[i], 14, p.text, sel));
            cell.setOnClickListener(v -> { Store.setTheme(this, k); build(); });
            tr.addView(cell, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        }
        col.addView(tr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));

        // ---- guide / about ----
        TextView guide = Ui.button(this, "📖  راهنمای استفاده از برنامه", p.primary, 0xFFFFFFFF);
        guide.setOnClickListener(v -> startActivity(new Intent(this, GuideActivity.class)));
        col.addView(guide, Ui.lp(this, Ui.MATCH, Ui.WRAP, 24));
        TextView about = Ui.button(this, "ℹ️  درباره برنامه و سازنده", p.primary, 0xFFFFFFFF);
        about.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        col.addView(about, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));

        // ---- phone calendar ----
        col.addView(Ui.text(this, "📆  تقویم گوشی", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 28));
        boolean linked = CalSync.has(this);
        TextView cs = Ui.text(this, linked
                ? "متصل است ✅ داروها و وقت‌های پزشک در تقویم گوشی هم ثبت می‌شوند. برای وقت پزشک، هشدار ۲۴ ساعت قبل و ۲ ساعت قبل در تقویم گوشی هم فعال می‌شود. رویدادهای تقویم گوشی هم در تقویم برنامه دیده می‌شوند."
                : "متصل نیست. برای ثبت در تقویم گوشی و دیدن رویدادهای آن، اجازه‌ی تقویم را بدهید.", 17, p.text, false);
        cs.setLineSpacing(0, 1.2f);
        col.addView(cs, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        if (!linked) {
            TextView link = Ui.button(this, "اتصال به تقویم گوشی", p.primary, 0xFFFFFFFF);
            link.setOnClickListener(v -> requestPermissions(new String[]{
                    "android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR"}, 2));
            col.addView(link, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        }

        // ---- reliability ----
        col.addView(Ui.text(this, "🔔  برای دقیق بودن زنگ", 20, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 28));
        TextView n = Ui.button(this, "تنظیمات اعلان‌ها", p.soft, p.text);
        n.setOnClickListener(v -> openNotificationSettings());
        col.addView(n, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        TextView bat = Ui.button(this, "تنظیمات باتری (بدون محدودیت)", p.soft, p.text);
        bat.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this, "این صفحه در گوشی شما پیدا نشد", Toast.LENGTH_SHORT).show();
            }
        });
        col.addView(bat, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
        col.addView(Ui.text(this, "نسخه ۳٫۳", 14, p.text, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 24));
        Ui.apply(this, sv);
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rc, perms, res);
        new Thread(() -> CalSync.heal(this)).start();
        build();
    }

    private void openNotificationSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()));
        }
        startActivity(i);
    }
}
