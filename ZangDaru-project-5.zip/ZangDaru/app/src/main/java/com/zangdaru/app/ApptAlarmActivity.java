package com.zangdaru.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Full-screen alarm shown (even on the lock screen) when a doctor visit is close. */
public class ApptAlarmActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        final int nid = getIntent().getIntExtra("nid", 0);
        int which = getIntent().getIntExtra("which", 0);
        Appt a = Store.getAppt(this, getIntent().getIntExtra("appt", -1));
        if (a == null) { Alarms.dismiss(this, nid); finish(); return; }

        Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(p.bg);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = Ui.text(this, which == 0 ? "فردا وقت پزشک دارید" : "۲ ساعت دیگر وقت پزشک دارید", 28, p.primary, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));
        TextView icon = Ui.text(this, "🩺", 90, p.text, false);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon, Ui.lp(this, Ui.MATCH, Ui.WRAP, 24));
        TextView doc = Ui.text(this, a.doctor, 34, p.text, true);
        doc.setGravity(Gravity.CENTER);
        root.addView(doc, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
        TextView date = Ui.text(this, Jalali.fmtFull(a.dateKey), 24, p.text, false);
        date.setGravity(Gravity.CENTER);
        root.addView(date, Ui.lp(this, Ui.MATCH, Ui.WRAP, 18));
        TextView time = Ui.text(this, "ساعت " + a.timeText(), 32, p.primary, true);
        time.setGravity(Gravity.CENTER);
        root.addView(time, Ui.lp(this, Ui.MATCH, Ui.WRAP, 6));
        if (!a.note.isEmpty()) {
            TextView note = Ui.text(this, a.note, 20, p.text, false);
            note.setGravity(Gravity.CENTER);
            root.addView(note, Ui.lp(this, Ui.MATCH, Ui.WRAP, 14));
        }
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(Ui.MATCH, 0, 1f);
        root.addView(new android.view.View(this), sp);
        TextView ok = Ui.button(this, "✅  متوجه شدم", 0xFF2E9E5B, Color.WHITE);
        ok.setTextSize(24);
        ok.setOnClickListener(v -> { Alarms.dismiss(this, nid); finish(); });
        root.addView(ok, Ui.lp(this, Ui.MATCH, Ui.dp(this, 70), 14));
        Ui.apply(this, root);
    }
}
