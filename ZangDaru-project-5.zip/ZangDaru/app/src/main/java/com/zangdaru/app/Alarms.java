package com.zangdaru.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import java.util.Calendar;

/** Scheduling through the phone's alarm-clock system + the ringing notification. */
final class Alarms {
    static final String CHANNEL = "zd_alarm_v1";
    static final String ACT_TAKEN = "com.zangdaru.app.TAKEN";
    static final String ACT_SNOOZE = "com.zangdaru.app.SNOOZE";

    /** Next time (ms) at which slot idx of the medication should ring after 'after', or -1. */
    static long nextTrigger(Med m, int idx, long after) {
        String[] hm = m.times.get(idx).split(":");
        int h = Integer.parseInt(hm[0]);
        int mi = Integer.parseInt(hm[1]);
        if (m.byDates()) {
            for (int key : m.dates) {
                long t = Jalali.millis(key, h, mi);
                if (t > after) return t;
            }
            return -1;
        }
        for (int d = 0; d < m.days; d++) {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(m.startMs);
            cal.add(Calendar.DAY_OF_YEAR, d);
            cal.set(Calendar.HOUR_OF_DAY, h);
            cal.set(Calendar.MINUTE, mi);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() > after) return cal.getTimeInMillis();
        }
        return -1;
    }

    static PendingIntent slotPi(Context c, int medId, int idx, boolean snooze) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.putExtra("med", medId);
        i.putExtra("idx", idx);
        i.putExtra("snooze", snooze);
        return PendingIntent.getBroadcast(c, medId * 200 + idx * 2 + (snooze ? 1 : 0), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void setAt(Context c, long when, PendingIntent pi) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent show = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(when, show), pi);
        } catch (Exception e) {
            try {
                am.set(AlarmManager.RTC_WAKEUP, when, pi);
            } catch (Exception e2) { /* too many alarms or not allowed */ }
        }
    }

    static void scheduleMed(Context c, Med m) {
        for (int i = 0; i < m.times.size(); i++) {
            long t = nextTrigger(m, i, System.currentTimeMillis());
            if (t > 0) setAt(c, t, slotPi(c, m.id, i, false));
        }
    }

    static void scheduleAll(Context c) {
        for (Med m : Store.all(c)) scheduleMed(c, m);
        for (Appt a : Store.allAppts(c)) scheduleAppt(c, a);
    }

    static void cancelMed(Context c, int medId) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        for (int i = 0; i < 30; i++) {
            am.cancel(slotPi(c, medId, i, false));
            am.cancel(slotPi(c, medId, i, true));
        }
    }

    static void dismiss(Context c, int nid) {
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(nid);
    }

    static void snooze(Context c, int medId, int idx, int nid) {
        dismiss(c, nid);
        if (medId < 0) return;
        setAt(c, System.currentTimeMillis() + 10 * 60 * 1000L, slotPi(c, medId, idx, true));
    }

    static void ring(Context c, Med m, int idx) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (snd == null) snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        long[] vib = new long[]{0, 700, 400, 700};
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "زنگ دارو", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(snd, aa);
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        int nid = m.id * 100 + idx;
        String time = m.times.get(idx);

        Intent open = new Intent(c, AlarmActivity.class);
        open.putExtra("med", m.id);
        open.putExtra("idx", idx);
        open.putExtra("nid", nid);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent full = PendingIntent.getActivity(c, nid, open, fl);

        Intent ti = new Intent(c, AlarmReceiver.class).setAction(ACT_TAKEN).putExtra("nid", nid);
        PendingIntent taken = PendingIntent.getBroadcast(c, nid, ti, fl);
        Intent si = new Intent(c, AlarmReceiver.class).setAction(ACT_SNOOZE)
                .putExtra("nid", nid).putExtra("med", m.id).putExtra("idx", idx);
        PendingIntent snoozePi = PendingIntent.getBroadcast(c, nid, si, fl);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("وقت مصرف دارو: " + m.name)
                .setContentText(Ui.fa(time) + (m.note.isEmpty() ? "" : " - " + m.note))
                .setContentIntent(full)
                .setFullScreenIntent(full, true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setAutoCancel(false)
                .addAction(android.R.drawable.ic_menu_save, "مصرف کردم", taken)
                .addAction(android.R.drawable.ic_menu_recent_history, "۱۰ دقیقه بعد", snoozePi);
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(snd, aa);
            b.setVibrate(vib);
            b.setPriority(Notification.PRIORITY_MAX);
        } else {
            b.setTimeoutAfter(10 * 60 * 1000L);   // the ring stops after 10 minutes if nobody answers
        }
        if (m.hasPhoto()) {
            Bitmap bmp = Ui.decodeFile(m.photo, 800);
            if (bmp != null) {
                b.setLargeIcon(bmp);
                b.setStyle(new Notification.BigPictureStyle().bigPicture(bmp));
            }
        }
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;   // keep ringing until the user answers
        nm.notify(nid, n);
    }

    // ================= doctor appointment reminders =================
    static final String APPT_CHANNEL = "zd_appt_v1";
    static final String ACT_APPT_OK = "com.zangdaru.app.APPT_OK";
    private static final long H = 3600L * 1000L;

    static PendingIntent apptPi(Context c, int apptId, int which) {
        Intent i = new Intent(c, ApptReceiver.class);
        i.putExtra("appt", apptId);
        i.putExtra("which", which);
        return PendingIntent.getBroadcast(c, 5000000 + apptId * 2 + which, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Two reminders: 24 hours before (which=0) and 2 hours before (which=1). */
    static void scheduleAppt(Context c, Appt a) {
        long t = a.millis(), now = System.currentTimeMillis();
        if (t - 24 * H > now) setAt(c, t - 24 * H, apptPi(c, a.id, 0));
        if (t - 2 * H > now) setAt(c, t - 2 * H, apptPi(c, a.id, 1));
    }

    static void cancelAppt(Context c, int apptId) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(apptPi(c, apptId, 0));
        am.cancel(apptPi(c, apptId, 1));
    }

    static void ringAppt(Context c, Appt a, int which) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (snd == null) snd = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        long[] vib = new long[]{0, 500, 300, 500};
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(APPT_CHANNEL, "وقت پزشک", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(snd, aa);
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        int nid = 900000 + a.id * 2 + which;
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        Intent oa = new Intent(c, ApptAlarmActivity.class);
        oa.putExtra("appt", a.id);
        oa.putExtra("which", which);
        oa.putExtra("nid", nid);
        oa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent open = PendingIntent.getActivity(c, nid, oa, fl);
        Intent oi = new Intent(c, ApptReceiver.class).setAction(ACT_APPT_OK).putExtra("nid", nid);
        PendingIntent ok = PendingIntent.getBroadcast(c, nid, oi, fl);

        String title = which == 0 ? "🩺 فردا وقت پزشک دارید" : "🩺 ۲ ساعت دیگر وقت پزشک دارید";
        String text = a.doctor + " - " + Jalali.fmtFull(a.dateKey) + " ساعت " + a.timeText();
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, APPT_CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(a.note.isEmpty() ? text : text + "\n" + a.note))
                .setContentIntent(open)
                .setFullScreenIntent(open, true)
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .addAction(android.R.drawable.ic_menu_save, "متوجه شدم", ok);
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(snd, aa);
            b.setVibrate(vib);
            b.setPriority(Notification.PRIORITY_MAX);
        } else {
            b.setTimeoutAfter(10 * 60 * 1000L);   // the ring stops after 10 minutes if nobody answers
        }
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;   // keeps ringing until the notification is opened or dismissed
        nm.notify(nid, n);
    }
}
